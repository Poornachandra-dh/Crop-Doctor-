from django.apps import AppConfig


class CropDocConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'crop_doc'
