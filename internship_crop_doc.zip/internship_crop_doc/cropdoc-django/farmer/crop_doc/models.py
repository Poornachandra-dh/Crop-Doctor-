from django.db import models
from django.contrib.auth.models import User

# class Farmer(models.Model):
#     name = models.CharField(max_length=100)
#     phone_no= models.IntegerField()
#     email = models.EmailField(null=True, blank=True) 
#     farm_address = models.CharField(max_length=50, null=True, blank=True)
#     gender=models.CharField(max_length=10, null=True, blank=True)
#     #USN=models.CharField(max_length=15, null=True, blank=True)
    
    
#     def __str__(self):
#         return self.name


class Task(models.Model):
    PRIORITY_CHOICES = [
        ('high', 'High'),
        ('medium', 'Medium'),
        ('low', 'Low'),
    ]

    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    name = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    due_date = models.DateField()
    priority = models.CharField(max_length=10, choices=PRIORITY_CHOICES, default='medium')
    created_at = models.DateTimeField(auto_now_add=True)
    completed = models.BooleanField(default=False)

    def __str__(self):
        return self.name
