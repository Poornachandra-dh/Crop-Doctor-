console.log('User from localStorage:', localStorage.getItem('user'));
document.addEventListener('DOMContentLoaded', function() {
    // Check if user is logged in
    const user = JSON.parse(localStorage.getItem('user'));
    if (!user) {
        window.location.href = 'login.html';
        return;
    }
    
    // Update user information in the dashboard using IDs
    const nameField = document.getElementById('profileName');
    const farmerIdField = document.getElementById('profileFarmerId');
    const emailField = document.getElementById('profileEmail');
    const phoneField = document.getElementById('profilePhone');
    const addressField = document.getElementById('profileAddress');
    const avatarImg = document.getElementById('profileAvatar');
    const usernameField = document.getElementById('profileUsername');

    const fullName = `${user.firstName || ''} ${user.lastName || ''}`.trim();
    if (nameField) nameField.textContent = fullName;
    if (usernameField) usernameField.textContent = fullName || 'User';
    if (farmerIdField) farmerIdField.textContent = `Farmer ID: ${user.farmerId || ''}`;
    if (emailField) emailField.textContent = user.email || '';
    if (phoneField) phoneField.textContent = user.phone || '';
    if (addressField) addressField.textContent = user.address || '';
    if (avatarImg) {
        if (fullName.length > 0) {
            avatarImg.src = `https://ui-avatars.com/api/?name=${encodeURIComponent(fullName)}&background=1e4d2b&color=fff&size=100`;
        } else {
            avatarImg.src = 'https://via.placeholder.com/100';
        }
    }
    
    // Handle edit profile button
    const editProfileBtn = document.querySelector('.btn-light');
    if (editProfileBtn) {
        editProfileBtn.addEventListener('click', function() {
            alert('Edit profile functionality will be implemented here');
        });
    }
    
    // Handle sidebar menu clicks
    const menuItems = document.querySelectorAll('.sidebar-menu a');
    menuItems.forEach(item => {
        item.addEventListener('click', function(e) {
            const href = this.getAttribute('href');
            if (href === '#') {
                e.preventDefault();
                alert('Navigation to ' + this.textContent.trim() + ' will be implemented here');
            } else if (href === 'index.html') {
                e.preventDefault();
                localStorage.removeItem('user');
                window.location.href = 'index.html';
            }
        });
    });
    
    // Handle logout
    const logoutBtn = document.querySelector('.sidebar-menu a.logout-link');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function(e) {
            e.preventDefault();
            localStorage.removeItem('user');
            window.location.href = 'index.html';
        });
    }
}); 