// OpenWeather API configuration
const API_KEY = '8d997f0f9d22631466275eb328df18a8';
let currentLocation = 'Bangalore'; // Default location
let temperatureChart = null;
let humidityChart = null;

// Fetch weather data from OpenWeather API
async function fetchWeatherData(location) {
    try {
        // Fetch current weather
        const currentResponse = await fetch(`https://api.openweathermap.org/data/2.5/weather?q=${location}&units=metric&appid=${API_KEY}`);
        const currentData = await currentResponse.json();
        
        // Fetch 5-day forecast
        const forecastResponse = await fetch(`https://api.openweathermap.org/data/2.5/forecast?q=${location}&units=metric&appid=${API_KEY}`);
        const forecastData = await forecastResponse.json();

        return {
            current: {
                temperature: Math.round(currentData.main.temp),
                humidity: currentData.main.humidity,
                rainfall: currentData.rain ? currentData.rain['1h'] || 0 : 0,
                windSpeed: Math.round(currentData.wind.speed * 3.6), // Convert m/s to km/h
                location: currentData.name,
                weatherIcon: currentData.weather[0].icon
            },
            hourly: forecastData.list.slice(0, 24).map(item => ({
                time: new Date(item.dt * 1000).toLocaleTimeString('en-US', { hour: 'numeric' }),
                temperature: Math.round(item.main.temp),
                humidity: item.main.humidity
            })),
            forecast: forecastData.list.filter((_, index) => index % 8 === 0).map(item => ({
                day: new Date(item.dt * 1000).toLocaleDateString('en-US', { weekday: 'short' }),
                temperature: {
                    high: Math.round(item.main.temp_max),
                    low: Math.round(item.main.temp_min)
                },
                humidity: item.main.humidity,
                icon: item.weather[0].icon
            }))
        };
    } catch (error) {
        console.error('Error fetching weather data:', error);
        return null;
    }
}

// Update current weather display
function updateCurrentWeather(weatherData) {
    document.getElementById('temperature').textContent = `${weatherData.current.temperature}°C`;
    document.getElementById('humidity').textContent = `${weatherData.current.humidity}%`;
    document.getElementById('rainfall').textContent = `${weatherData.current.rainfall} mm`;
    document.getElementById('windSpeed').textContent = `${weatherData.current.windSpeed} km/h`;
    document.getElementById('currentLocation').textContent = weatherData.current.location;
    document.getElementById('updateTime').textContent = new Date().toLocaleTimeString();
}

// Create or update temperature chart
function updateTemperatureChart(weatherData) {
    const ctx = document.getElementById('temperatureChart').getContext('2d');
    
    if (temperatureChart) {
        temperatureChart.destroy();
    }

    temperatureChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: weatherData.hourly.map(h => h.time),
            datasets: [{
                label: 'Temperature (°C)',
                data: weatherData.hourly.map(h => h.temperature),
                borderColor: '#FF5252',
                backgroundColor: 'rgba(255, 82, 82, 0.1)',
                tension: 0.4,
                fill: true
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top',
                }
            },
            scales: {
                y: {
                    beginAtZero: false
                }
            }
        }
    });
}

// Create or update humidity chart
function updateHumidityChart(weatherData) {
    const ctx = document.getElementById('humidityChart').getContext('2d');
    
    if (humidityChart) {
        humidityChart.destroy();
    }

    humidityChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: weatherData.hourly.map(h => h.time),
            datasets: [{
                label: 'Humidity (%)',
                data: weatherData.hourly.map(h => h.humidity),
                borderColor: '#81D4FA',
                backgroundColor: 'rgba(129, 212, 250, 0.1)',
                tension: 0.4,
                fill: true
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top',
                }
            },
            scales: {
                y: {
                    beginAtZero: false,
                    max: 100
                }
            }
        }
    });
}

// Update risk assessment
function updateRiskAssessment(weatherData) {
    const riskAlerts = document.getElementById('riskAlerts');
    riskAlerts.innerHTML = '';

    if (weatherData.current.humidity > 70) {
        riskAlerts.innerHTML += `
            <div class="risk-alert">
                <i class="fas fa-exclamation-triangle"></i>
                <span data-translate>High humidity detected: Watch for fungal diseases</span>
            </div>
        `;
    }

    if (weatherData.current.temperature > 30) {
        riskAlerts.innerHTML += `
            <div class="risk-alert">
                <i class="fas fa-exclamation-triangle"></i>
                <span data-translate>High temperature: Plants may experience heat stress</span>
            </div>
        `;
    }

    if (weatherData.current.rainfall > 10) {
        riskAlerts.innerHTML += `
            <div class="risk-alert">
                <i class="fas fa-exclamation-triangle"></i>
                <span data-translate>Heavy rainfall: Monitor for waterlogging</span>
            </div>
        `;
    }

    if (riskAlerts.innerHTML === '') {
        riskAlerts.innerHTML = `
            <div class="risk-alert" style="background: rgba(76, 175, 80, 0.1); border-left-color: var(--primary-color);">
                <i class="fas fa-check-circle" style="color: var(--primary-color);"></i>
                <span data-translate>Current conditions are favorable for plant growth</span>
            </div>
        `;
    }
}

// Update forecast
function updateForecast(weatherData) {
    const forecastContainer = document.getElementById('forecastContainer');
    forecastContainer.innerHTML = weatherData.forecast.map(day => `
        <div class="forecast-day">
            <h4>${day.day}</h4>
            <img src="https://openweathermap.org/img/wn/${day.icon}@2x.png" alt="Weather icon">
            <p>${day.temperature.high}° / ${day.temperature.low}°</p>
            <p>${day.humidity}%</p>
        </div>
    `).join('');

    // Update crop suggestions when weather data is available
    updateCropSuggestions(weatherData.current.temperature, weatherData.current.humidity);
}

// Fetch crop suggestions from DeepSeek API
async function fetchCropSuggestions(temperature, humidity) {
    try {
        const response = await fetch('https://api.deepseek.com/v1/crop-suggestions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer YOUR_DEEPSEEK_API_KEY' // Replace with actual API key
            },
            body: JSON.stringify({
                temperature: temperature,
                humidity: humidity,
                location: currentLocation
            })
        });

        if (!response.ok) {
            throw new Error('Failed to fetch crop suggestions');
        }

        const data = await response.json();
        return data.suggestions;
    } catch (error) {
        console.error('Error fetching crop suggestions:', error);
        // Fallback to local recommendations if API fails
        return getLocalCropSuggestions(temperature, humidity);
    }
}

// Local fallback for crop suggestions
function getLocalCropSuggestions(temperature, humidity) {
    const suggestions = [];
    
    // Temperature-based suggestions with more detailed ranges
    if (temperature >= 20 && temperature <= 35) {
        if (humidity >= 60) {
            suggestions.push({
                name: 'Rice',
                description: 'Ideal for warm and humid conditions (20-35°C, 60-100% humidity)',
                image: '../images/crops/rice.jpg',
                idealTemp: '20-35°C',
                idealHumidity: '60-100%',
                growingSeason: 'Kharif (June-October)'
            });
        }
        suggestions.push({
            name: 'Maize',
            description: 'Thrives in warm temperatures (20-35°C)',
            image: '../images/crops/maize.jpg',
            idealTemp: '20-35°C',
            idealHumidity: '50-80%',
            growingSeason: 'Kharif (June-October)'
        });
    }
    
    if (temperature >= 15 && temperature <= 30) {
        suggestions.push({
            name: 'Wheat',
            description: 'Grows well in moderate temperatures (15-30°C)',
            image: '../images/crops/wheat.jpg',
            idealTemp: '15-30°C',
            idealHumidity: '40-70%',
            growingSeason: 'Rabi (October-March)'
        });
    }
    
    if (temperature >= 15 && temperature <= 25) {
        suggestions.push({
            name: 'Potatoes',
            description: 'Prefers cooler temperatures (15-25°C)',
            image: '../images/crops/potatoes.jpg',
            idealTemp: '15-25°C',
            idealHumidity: '50-80%',
            growingSeason: 'Rabi (October-March)'
        });
    }

    // Humidity-based suggestions
    if (humidity >= 70) {
        suggestions.push({
            name: 'Sugarcane',
            description: 'Requires high humidity (70-100%)',
            image: '../images/crops/sugarcane.jpg',
            idealTemp: '20-35°C',
            idealHumidity: '70-100%',
            growingSeason: 'Kharif (June-October)'
        });
    }

    if (humidity >= 50 && humidity <= 70) {
        suggestions.push({
            name: 'Cotton',
            description: 'Moderate humidity is ideal (50-70%)',
            image: '../images/crops/cotton.jpg',
            idealTemp: '20-35°C',
            idealHumidity: '50-70%',
            growingSeason: 'Kharif (June-October)'
        });
    }

    // Additional crops for different conditions
    if (temperature >= 25 && temperature <= 35 && humidity >= 50) {
        suggestions.push({
            name: 'Soybean',
            description: 'Suitable for warm and moderately humid conditions',
            image: '../images/crops/soybean.jpg',
            idealTemp: '25-35°C',
            idealHumidity: '50-80%',
            growingSeason: 'Kharif (June-October)'
        });
    }

    if (temperature >= 20 && temperature <= 30 && humidity >= 40) {
        suggestions.push({
            name: 'Groundnut',
            description: 'Grows well in warm temperatures with moderate humidity',
            image: '../images/crops/groundnut.jpg',
            idealTemp: '20-30°C',
            idealHumidity: '40-70%',
            growingSeason: 'Kharif (June-October)'
        });
    }

    return suggestions;
}

// Update crop suggestions display
async function updateCropSuggestions(temperature, humidity) {
    const cropSuggestionsContainer = document.getElementById('cropSuggestions');
    
    try {
        const suggestions = await fetchCropSuggestions(temperature, humidity);
        
        if (suggestions.length === 0) {
            cropSuggestionsContainer.innerHTML = `
                <div class="crop-suggestion-card">
                    <div class="crop-suggestion-info">
                        <h3 data-translate>No specific recommendations</h3>
                        <p data-translate>Current conditions may not be ideal for most crops. Consider adjusting your farming schedule.</p>
                    </div>
                </div>
            `;
            return;
        }

        cropSuggestionsContainer.innerHTML = suggestions.map(crop => `
            <div class="crop-suggestion-card">
                <img src="${crop.image}" alt="${crop.name}">
                <div class="crop-suggestion-info">
                    <h3>${crop.name}</h3>
                    <p>${crop.description}</p>
                    <div class="crop-details">
                        <p><strong>Ideal Temperature:</strong> ${crop.idealTemp}</p>
                        <p><strong>Ideal Humidity:</strong> ${crop.idealHumidity}</p>
                        <p><strong>Growing Season:</strong> ${crop.growingSeason}</p>
                    </div>
                </div>
            </div>
        `).join('');
    } catch (error) {
        cropSuggestionsContainer.innerHTML = `
            <div class="crop-suggestion-card">
                <div class="crop-suggestion-info">
                    <h3 data-translate>Error loading suggestions</h3>
                    <p data-translate>Unable to fetch crop recommendations at this time. Please try again later.</p>
                </div>
            </div>
        `;
    }
}

// Search for location
async function searchLocation() {
    const locationInput = document.getElementById('locationInput');
    const location = locationInput.value.trim();
    
    if (location) {
        currentLocation = location;
        localStorage.setItem('environmentLocation', location); // Store for dashboard
        const weatherData = await fetchWeatherData(location);
        
        if (weatherData) {
            updateCurrentWeather(weatherData);
            updateTemperatureChart(weatherData);
            updateHumidityChart(weatherData);
            updateRiskAssessment(weatherData);
            updateForecast(weatherData);
        } else {
            alert('Location not found. Please try again.');
        }
    }
}

// Initialize the page
async function init() {
    const weatherData = await fetchWeatherData(currentLocation);
    
    if (weatherData) {
        updateCurrentWeather(weatherData);
        updateTemperatureChart(weatherData);
        updateHumidityChart(weatherData);
        updateRiskAssessment(weatherData);
        updateForecast(weatherData);
    }

    // Update weather every 5 minutes
    setInterval(async () => {
        const weatherData = await fetchWeatherData(currentLocation);
        if (weatherData) {
            updateCurrentWeather(weatherData);
            updateTemperatureChart(weatherData);
            updateHumidityChart(weatherData);
            updateRiskAssessment(weatherData);
            updateForecast(weatherData);
        }
    }, 300000);
}

// Initialize when the page loads
window.onload = init; 