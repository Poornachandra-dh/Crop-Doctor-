document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.getElementById('loginForm');
    
    loginForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;
        
        // Here you would typically make an API call to your backend
        // For now, we'll simulate a successful login
        if (email && password) {
            // Store user data in localStorage (in a real app, you'd use a more secure method)
            localStorage.setItem('user', JSON.stringify({
                email: email,
                name: 'John Doe', // This would come from your backend
                farmerId: '#12345'
            }));
            
            // Redirect to dashboard
            window.location.href = 'user-dashboard.html';
        } else {
            alert('Please fill in all fields');
        }
    });
}); 