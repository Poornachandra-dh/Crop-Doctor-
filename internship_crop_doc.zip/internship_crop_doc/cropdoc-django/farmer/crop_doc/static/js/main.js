// Daily farming tips
const farmingTips = [
    "Regular monitoring of crop health can prevent major disease outbreaks.",
    "Water your plants early in the morning for best results.",
    "Rotate your crops to maintain soil health and prevent disease buildup.",
    "Use organic compost to improve soil fertility naturally.",
    "Keep a record of weather patterns to better predict disease risks.",
    "Prune affected leaves immediately to prevent disease spread.",
    "Maintain proper spacing between plants for good air circulation.",
    "Test your soil regularly to ensure proper nutrient balance."
];

// Update daily tip
function updateDailyTip() {
    const tipElement = document.getElementById('daily-tip-text');
    if (tipElement) {
        const randomTip = farmingTips[Math.floor(Math.random() * farmingTips.length)];
        tipElement.textContent = randomTip;
    }
}

// Typing animation for greeting
function typeGreeting(text, element) {
    element.textContent = '';
    let i = 0;
    function type() {
        if (i < text.length) {
            element.textContent += text.charAt(i);
            i++;
            setTimeout(type, 50); // typing speed in ms
        }
    }
    type();
}

// Update greeting based on time of day with typing animation
function updateGreeting() {
    const greetingElement = document.getElementById('greeting');
    if (!greetingElement) return;

    const hour = new Date().getHours();
    let greeting = '';

    if (hour >= 5 && hour < 12) {
        greeting = 'Good Morning';
    } else if (hour >= 12 && hour < 17) {
        greeting = 'Good Afternoon';
    } else if (hour >= 17 && hour < 21) {
        greeting = 'Good Evening';
    } else {
        greeting = 'Good Night';
    }

    const fullGreeting = `${greeting}, Farmer!`;
    greetingElement.setAttribute('data-translate', fullGreeting);
    typeGreeting(fullGreeting, greetingElement);
}

// Add animation classes to elements
function addAnimationClasses() {
    const elements = document.querySelectorAll('.action-card, .status-card, .tip-card');
    elements.forEach((element, index) => {
        element.classList.add('fade-in');
        element.style.animationDelay = `${index * 0.1}s`;
    });
}

// --- Dashboard Weather Panel Logic ---
const DASHBOARD_API_KEY = '8d997f0f9d22631466275eb328df18a8';

async function fetchDashboardWeather(location) {
    try {
        const response = await fetch(`https://api.openweathermap.org/data/2.5/weather?q=${location}&units=metric&appid=${DASHBOARD_API_KEY}`);
        const data = await response.json();
        return {
            location: data.name,
            temperature: Math.round(data.main.temp),
            description: data.weather[0].description,
            icon: data.weather[0].icon
        };
    } catch (error) {
        return null;
    }
}

function updateDashboardWeatherPanel(weather) {
    const loc = document.getElementById('dashboardLocation');
    const weatherSpan = document.getElementById('dashboardWeather');
    if (weather && loc && weatherSpan) {
        loc.textContent = weather.location;
        weatherSpan.innerHTML = `<img src='https://openweathermap.org/img/wn/${weather.icon}.png' alt='' style='vertical-align:middle;width:32px;height:32px;margin-right:8px;'>${weather.temperature}°C, ${weather.description}`;
    } else if (loc && weatherSpan) {
        loc.textContent = 'Unavailable';
        weatherSpan.textContent = 'Weather unavailable';
    }
    if (window.retranslate) window.retranslate();
    showDiseaseAlert(); // update alert after weather update
}

function getDashboardLocationAndWeather() {
    // Check if a location was searched in environment page
    const storedLocation = localStorage.getItem('environmentLocation');
    if (storedLocation) {
        fetchDashboardWeather(storedLocation).then(updateDashboardWeatherPanel);
        return;
    }
    // Try geolocation, fallback to Bangalore
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(async (pos) => {
            const lat = pos.coords.latitude;
            const lon = pos.coords.longitude;
            try {
                const response = await fetch(`https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&units=metric&appid=${DASHBOARD_API_KEY}`);
                const data = await response.json();
                updateDashboardWeatherPanel({
                    location: data.name,
                    temperature: Math.round(data.main.temp),
                    description: data.weather[0].description,
                    icon: data.weather[0].icon
                });
            } catch {
                fetchDashboardWeather('Bangalore').then(updateDashboardWeatherPanel);
            }
        }, () => {
            fetchDashboardWeather('Bangalore').then(updateDashboardWeatherPanel);
        });
    } else {
        fetchDashboardWeather('Bangalore').then(updateDashboardWeatherPanel);
    }
}

// --- End Dashboard Weather Panel Logic ---

// --- Disease Alert Logic ---
async function showDiseaseAlert() {
    const alertDiv = document.getElementById('disease-alert');
    if (!alertDiv) return;

    let location = localStorage.getItem('environmentLocation') || 'Bangalore';
    const apiKey = '8d997f0f9d22631466275eb328df18a8';
    try {
        const response = await fetch(`https://api.openweathermap.org/data/2.5/weather?q=${location}&units=metric&appid=${apiKey}`);
        const data = await response.json();
        const temp = data.main.temp;
        const humidity = data.main.humidity;
        const weather = data.weather[0].main.toLowerCase();
        const description = data.weather[0].description.toLowerCase();
        const month = new Date().getMonth() + 1;
        const rain = data.rain && (data.rain['1h'] || data.rain['3h'] || data.rain['24h']) ? (data.rain['1h'] || data.rain['3h'] || data.rain['24h']) : 0;

        // Determine season (India-centric)
        let season = '';
        if (month >= 6 && month <= 9) season = 'Monsoon';
        else if (month >= 10 && month <= 11) season = 'Post-Monsoon';
        else if (month >= 12 || month <= 2) season = 'Winter';
        else season = 'Summer';

        // Dynamic, actionable messages
        let riskMsg = '';
        let icon = '<i class="fas fa-exclamation-triangle"></i>';
        if (season === 'Monsoon') {
            if (humidity > 85 && rain > 5) {
                riskMsg = `Heavy rainfall and high humidity detected in the ${season} season. High risk of fungal diseases (blight, mildew, root rot). Ensure good drainage and avoid waterlogging.`;
            } else if (humidity > 80) {
                riskMsg = `High humidity in the ${season} season increases risk of leaf spot and mildew. Regularly inspect crops and use preventive fungicides if needed.`;
            } else if (rain > 10) {
                riskMsg = `Intense rainfall in the ${season} season can cause waterborne diseases. Check for standing water and improve field drainage.`;
            }
        } else if (season === 'Summer') {
            if (temp > 35 && humidity > 60) {
                riskMsg = `Hot and humid summer conditions favor bacterial wilt and fruit rot. Water early in the morning and avoid overhead irrigation.`;
            } else if (temp > 38) {
                riskMsg = `Extreme heat detected. Plants may be stressed and more susceptible to pests and diseases. Provide shade and mulch to retain soil moisture.`;
            }
        } else if (season === 'Winter') {
            if (humidity > 75 && temp < 20) {
                riskMsg = `Cool and moist winter weather can promote powdery mildew and rust. Remove infected leaves and ensure good air flow.`;
            } else if (temp < 10) {
                riskMsg = `Low temperatures detected. Some crops may be at risk of frost damage or slow growth. Consider protective covers for sensitive plants.`;
            }
        } else if (season === 'Post-Monsoon') {
            if (humidity > 80) {
                riskMsg = `High humidity in the post-monsoon season can trigger late blight and downy mildew. Monitor crops closely and act at first signs of disease.`;
            }
        }
        // Rain or weather-based alerts
        if (!riskMsg && (weather.includes('rain') || description.includes('rain'))) {
            riskMsg = `Recent rainfall detected. Watch for waterborne diseases and ensure proper drainage.`;
        }
        if (!riskMsg && humidity > 90) {
            riskMsg = `Very high humidity detected. Fungal diseases are more likely. Increase field monitoring.`;
        }
        if (!riskMsg && temp > 40) {
            riskMsg = `Extreme heat detected. Plants may be vulnerable to heat stress and disease. Provide shade and adequate water.`;
        }
        if (!riskMsg) {
            alertDiv.style.display = 'none';
            return;
        }
        alertDiv.innerHTML = `${icon}<span data-translate>${riskMsg}</span>`;
        alertDiv.style.display = 'flex';
        if (window.retranslate) window.retranslate();
    } catch (e) {
        alertDiv.style.display = 'none';
    }
}

// Call on load and after weather update
showDiseaseAlert();

// Initialize the application
function init() {
    updateDailyTip();
    updateGreeting();
    addAnimationClasses();
    getDashboardLocationAndWeather();
    
    // Update tip every 30 seconds
    setInterval(updateDailyTip, 30000);
    
    // Update greeting every minute
    setInterval(updateGreeting, 60000);
}

// Run initialization when DOM is loaded
document.addEventListener('DOMContentLoaded', init);

// Add smooth scrolling to all links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth'
        });
    });
});

// Add click effect to action cards
document.querySelectorAll('.action-card').forEach(card => {
    card.addEventListener('click', function() {
        this.style.transform = 'scale(0.95)';
        setTimeout(() => {
            this.style.transform = '';
        }, 200);
    });
}); 