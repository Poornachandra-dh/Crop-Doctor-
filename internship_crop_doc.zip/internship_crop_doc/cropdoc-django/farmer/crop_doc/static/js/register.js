document.addEventListener('DOMContentLoaded', function() {
    const registerForm = document.getElementById('registerForm');
    
    registerForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const firstName = document.getElementById('firstName').value;
        const lastName = document.getElementById('lastName').value;
        const email = document.getElementById('email').value;
        const phone = document.getElementById('phone').value;
        const address = document.getElementById('address').value;
        const password = document.getElementById('password').value;
        const confirmPassword = document.getElementById('confirmPassword').value;
        
        // Basic validation
        if (!firstName || !lastName || !email || !phone || !address || !password || !confirmPassword) {
            alert('Please fill in all fields');
            return;
        }
        
        if (password !== confirmPassword) {
            alert('Passwords do not match');
            return;
        }
        
        // Save all fields to localStorage
        const userData = {
            firstName: firstName,
            lastName: lastName,
            email: email,
            phone: phone,
            address: address,
            farmerId: '#' + Math.floor(Math.random() * 100000)
        };
        
        localStorage.setItem('user', JSON.stringify(userData));
        window.location.href = 'login.html';
    });
}); 