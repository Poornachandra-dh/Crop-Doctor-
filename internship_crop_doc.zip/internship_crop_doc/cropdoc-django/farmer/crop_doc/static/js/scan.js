// Mock disease data for simulation
const mockDiseases = [
    {
        name: "Leaf Rust",
        confidence: 85,
        organicSolutions: [
            "Remove and destroy infected leaves",
            "Apply neem oil spray every 7-10 days",
            "Improve air circulation around plants"
        ],
        chemicalSolutions: [
            "Apply fungicide containing chlorothalonil",
            "Follow manufacturer's instructions for application",
            "Wear protective gear during application"
        ]
    },
    {
        name: "Powdery Mildew",
        confidence: 75,
        organicSolutions: [
            "Spray with baking soda solution",
            "Remove affected plant parts",
            "Ensure proper spacing between plants"
        ],
        chemicalSolutions: [
            "Apply sulfur-based fungicide",
            "Use potassium bicarbonate spray",
            "Follow safety guidelines for application"
        ]
    },
    {
        name: "Bacterial Blight",
        confidence: 90,
        organicSolutions: [
            "Remove infected plants immediately",
            "Use copper-based sprays",
            "Practice crop rotation"
        ],
        chemicalSolutions: [
            "Apply copper-based bactericides",
            "Use streptomycin sulfate",
            "Follow strict application schedule"
        ]
    }
];

// DOM Elements
const uploadArea = document.getElementById('uploadArea');
const fileInput = document.getElementById('fileInput');
const imagePreview = document.getElementById('imagePreview');
const analyzeBtn = document.getElementById('analyzeBtn');
const loading = document.getElementById('loading');
const resultContainer = document.getElementById('resultContainer');
const diseaseName = document.getElementById('diseaseName');
const confidenceFill = document.getElementById('confidenceFill');
const confidenceText = document.getElementById('confidenceText');
const confidenceLevel = document.getElementById('confidenceLevel');
const organicSolutions = document.getElementById('organicSolutions');
const chemicalSolutions = document.getElementById('chemicalSolutions');

// Handle drag and drop events
uploadArea.addEventListener('dragover', (e) => {
    e.preventDefault();
    uploadArea.style.backgroundColor = 'rgba(76, 175, 80, 0.1)';
});

uploadArea.addEventListener('dragleave', () => {
    uploadArea.style.backgroundColor = '';
});

uploadArea.addEventListener('drop', (e) => {
    e.preventDefault();
    uploadArea.style.backgroundColor = '';
    const file = e.dataTransfer.files[0];
    handleFile(file);
});

// Handle file input change
fileInput.addEventListener('change', (e) => {
    const file = e.target.files[0];
    handleFile(file);
});

// Handle file selection
function handleFile(file) {
    if (file && file.type.startsWith('image/')) {
        const reader = new FileReader();
        reader.onload = (e) => {
            imagePreview.src = e.target.result;
            imagePreview.style.display = 'block';
            analyzeBtn.disabled = false;
        };
        reader.readAsDataURL(file);
    }
}

// Replace simulateAnalysis function with real API call
async function analyzeImage() {
    loading.style.display = 'block';
    resultContainer.style.display = 'none';
    analyzeBtn.disabled = true;

    try {
        // 1. Upload image to imgbb
        const imgbbApiKey = '318c126906609b8f2b8e7046550a0a83';
        const base64Image = imagePreview.src.split(',')[1];
        const imgbbResponse = await fetch(`https://api.imgbb.com/1/upload?key=${imgbbApiKey}`, {
            method: 'POST',
            body: new URLSearchParams({
                image: base64Image
            })
        });
        
        if (!imgbbResponse.ok) {
            throw new Error('Failed to upload image to imgbb');
        }
        
        const imgbbData = await imgbbResponse.json();
        if (!imgbbData.success) {
            throw new Error('Image upload failed: ' + (imgbbData.error?.message || 'Unknown error'));
        }
        const imageUrl = imgbbData.data.url;

        // 2. Send public image URL to OpenRouter with fallback models
        const contentArr = [
            {
                "type": "text",
                "text": `You are an expert plant pathologist. Analyze the following crop image and provide:\n- The most likely disease name (or \"Unknown\" if not sure)\n- Confidence score (0 to 1)\n- List of visible symptoms observed in the image\n- List of possible causes\n- Step-by-step organic and chemical treatment recommendations (as arrays)\n- If the disease is unknown, explain why and give general advice\n\nFormat your response as JSON:\n{\n  \"disease\": string,\n  \"confidence\": number,\n  \"symptoms\": string[],\n  \"causes\": string[],\n  \"organicSolutions\": string[],\n  \"chemicalSolutions\": string[],\n  \"explanation\": string\n}`
            },
            {
                "type": "image_url",
                "image_url": {
                    "url": imageUrl
                }
            }
        ];

        // List of models to try in order of preference
        const models = [
            'mistralai/mistral-7b-instruct:free',
            'meta-llama/llama-2-70b-chat:free',
            'openchat/openchat-3.5-0106:free'
        ];

        let lastError = null;
        let analysis = null;

        for (const model of models) {
            try {
                const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
                    method: "POST",
                    headers: {
                        "Authorization": "Bearer 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",
                        "HTTP-Referer": window.location.origin,
                        "X-Title": "Crop Doctor",
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        "model": model,
                        "messages": [
                            {
                                "role": "user",
                                "content": contentArr
                            }
                        ]
                    })
                });

                if (!response.ok) {
                    throw new Error(`API request failed with status ${response.status}`);
                }

                const data = await response.json();
                console.log('OpenRouter response:', JSON.stringify(data, null, 2));

                if (data.choices && data.choices[0]?.message?.content) {
                    try {
                        let content = data.choices[0].message.content.trim();
                        // Remove code block markers if present
                        if (content.startsWith('```json')) {
                            content = content.replace(/^```json/, '').replace(/```$/, '').trim();
                        } else if (content.startsWith('```')) {
                            content = content.replace(/^```/, '').replace(/```$/, '').trim();
                        }
                        analysis = JSON.parse(content);
                        break; // Successfully got analysis, exit the loop
                    } catch (e) {
                        console.warn(`Failed to parse response from ${model}:`, e);
                        lastError = new Error('AI response could not be parsed as JSON');
                        continue; // Try next model
                    }
                } else if (data.error) {
                    throw new Error(data.error.message || 'Unknown API error');
                }
            } catch (error) {
                console.warn(`Error with model ${model}:`, error);
                lastError = error;
                continue; // Try next model
            }
        }

        if (!analysis) {
            throw lastError || new Error('No valid response from any AI model');
        }

        // Update results (detailed)
        diseaseName.textContent = analysis.disease || 'Unknown';
        confidenceText.textContent = analysis.confidence ? `${Math.round(analysis.confidence * 100)}%` : 'N/A';
        setTimeout(() => {
            confidenceFill.style.width = analysis.confidence ? `${analysis.confidence * 100}%` : '0%';
        }, 100);

        // Detailed fields
        const organicList = document.querySelector('.organic ul');
        const chemicalList = document.querySelector('.chemical ul');
        const symptomsSection = document.createElement('div');
        const causesSection = document.createElement('div');

        // Symptoms
        symptomsSection.innerHTML = analysis.symptoms && Array.isArray(analysis.symptoms)
            ? `<h4>Symptoms</h4><ul>${analysis.symptoms.map(s => `<li>${s}</li>`).join('')}</ul>`
            : '';
        // Causes
        causesSection.innerHTML = analysis.causes && Array.isArray(analysis.causes)
            ? `<h4>Causes</h4><ul>${analysis.causes.map(c => `<li>${c}</li>`).join('')}</ul>`
            : '';

        // Insert symptoms and causes above the treatment advice
        const diseaseInfo = resultContainer.querySelector('.disease-info');
        // Remove previous if any
        const oldSymptoms = resultContainer.querySelector('.ai-symptoms');
        const oldCauses = resultContainer.querySelector('.ai-causes');
        if (oldSymptoms) oldSymptoms.remove();
        if (oldCauses) oldCauses.remove();
        if (symptomsSection.innerHTML) {
            symptomsSection.className = 'ai-symptoms';
            diseaseInfo.appendChild(symptomsSection);
        }
        if (causesSection.innerHTML) {
            causesSection.className = 'ai-causes';
            diseaseInfo.appendChild(causesSection);
        }

        organicList.innerHTML = Array.isArray(analysis.organicSolutions)
            ? analysis.organicSolutions.map(solution => `<li>${solution}</li>`).join('')
            : '<li>No organic solutions available</li>';
        chemicalList.innerHTML = Array.isArray(analysis.chemicalSolutions)
            ? analysis.chemicalSolutions.map(solution => `<li>${solution}</li>`).join('')
            : '<li>No chemical solutions available</li>';

        // Store analysis in localStorage
        localStorage.setItem('lastAnalysis', JSON.stringify({
            disease: analysis.disease,
            confidence: analysis.confidence,
            timestamp: new Date().toISOString(),
            fullAnalysis: analysis // Store complete analysis
        }));

        // Show results
        resultContainer.style.display = 'block';

    } catch (error) {
        console.error('Error analyzing image:', error);
        
        // Update UI with error message
        diseaseName.textContent = 'Error';
        confidenceText.textContent = 'N/A';
        confidenceFill.style.width = '0%';
        
        const organicList = document.querySelector('.organic ul');
        const chemicalList = document.querySelector('.chemical ul');
        
        organicList.innerHTML = `
            <li>We encountered an error while analyzing your image.</li>
            <li>Please try again in a few minutes.</li>
            <li>Error details: ${error.message}</li>
        `;
        
        chemicalList.innerHTML = `
            <li>In the meantime, you can:</li>
            <li>Try uploading a different image</li>
            <li>Check our knowledge base for common crop diseases</li>
            <li>Contact support if the issue persists</li>
        `;
        
        resultContainer.style.display = 'block';
    } finally {
        loading.style.display = 'none';
        analyzeBtn.disabled = false;
    }
}

// Update event listener to use new analyzeImage function
analyzeBtn.addEventListener('click', analyzeImage);

// Add click event to upload area
uploadArea.addEventListener('click', () => {
    fileInput.click();
}); 