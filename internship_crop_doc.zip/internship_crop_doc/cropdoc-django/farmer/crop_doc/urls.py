from django.contrib.auth import views as auth_views
from django.urls import path
from .views import login_view
from . import views

urlpatterns = [
    path('', views.home_view, name='home'),
    path('login/', auth_views.LoginView.as_view(template_name='crop_doc/login.html'), name='login'),
    path('register/',views.register_view, name='register'),
    path('environment/', views.environment_view, name='environment'),
    path('market/', views.market_view, name='market'),
    path('knowledge/', views.knowledge_view, name='knowledge'),
    path('index/', views.index_view, name='index'), 
    path('scan/', views.scan_view, name='scan'), 
    path('userdashboard/', views.userdashboard_view, name='userdashboard'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('tasks/', views.tasks_view, name='tasks'),
    path('tasks/delete/<int:task_id>/', views.delete_task, name='delete_task'),


    

]