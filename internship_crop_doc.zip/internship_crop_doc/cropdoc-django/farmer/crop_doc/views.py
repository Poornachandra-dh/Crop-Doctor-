from django.shortcuts import render,redirect
from django.contrib.auth import authenticate, login,logout
from django.contrib import messages
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse
from django.contrib.auth.models import User
from datetime import datetime
from django.utils import timezone



from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from datetime import datetime
from django.utils import timezone
from .models import Task

@login_required(login_url='login')
def tasks_view(request):
    user = request.user
    
    if request.method == 'POST':
        if 'task_id' in request.POST:  # Update operation
            task_id = request.POST.get('task_id')
            task = Task.objects.get(id=task_id, user=user)
            
            task.name = request.POST.get('taskName')
            task.description = request.POST.get('description')
            task.due_date = request.POST.get('dueDate')
            task.priority = request.POST.get('priority')
            task.completed = request.POST.get('completed') == 'on'
            task.save()
            messages.success(request, 'Task updated successfully!')
        else:  # Create operation
            try:
                task_name = request.POST.get('taskName')
                due_date = request.POST.get('dueDate')
                priority = request.POST.get('priority')
                description = request.POST.get('description')

                Task.objects.create(
                    user=user,
                    name=task_name,
                    due_date=due_date,
                    priority=priority,
                    description=description
                )
                messages.success(request, 'Task added successfully!')
            except Exception as e:
                messages.error(request, f'Error creating task: {str(e)}')

        return redirect('tasks')

    # GET request - show tasks
    tasks = Task.objects.filter(user=user).order_by('due_date')
    return render(request, 'crop_doc/tasks.html', {
        'tasks': tasks
    })

@login_required(login_url='login')
def delete_task(request, task_id):
    try:
        task = Task.objects.get(id=task_id, user=request.user)
        task.delete()
        messages.success(request, 'Task deleted successfully!')
    except Task.DoesNotExist:
        messages.error(request, 'Task not found!')
    except Exception as e:
        messages.error(request, f'Error deleting task: {str(e)}')
    
    return redirect('tasks')

@login_required(login_url='login')
def dashboard(request):
    try:
        user = request.user
        upcoming_tasks = Task.objects.filter(user=user, due_date__gt=timezone.now())
        
        return render(request, 'crop_doc/dashboard.html', {
            'upcoming_tasks_count': upcoming_tasks.count()
        })
    except Exception as e:
        messages.error(request, 'Error fetching dashboard data')
        return redirect('login')

def home_view(request):
    return render(request, 'crop_doc/home.html')

#def register_view(request):
   # if request.method == 'POST':
        #form = UserCreationForm(request.POST)
        #if form.is_valid():
            #form.save()
            #return redirect('login')
    #else:
        #form = UserCreationForm()
    #return render(request, 'crop_doc/register.html', {'form': form})


# def register_view(request):
#     if request.method == 'POST':
#         uname = request.POST.get('name')
#         email = request.POST.get('email')
#         pass1 = request.POST.get('password1')
#         pass2 = request.POST.get('password2')

#         if pass1 != pass2:
#             return HttpResponse("Your password and confirm password are not the same!")
#         else:
#             if User.objects.filter(username=uname).exists():
#                 return HttpResponse("Username already exists!")
#             elif User.objects.filter(email=email).exists():
#                 return HttpResponse("Email already registered!")
#             else:
#                 user = User.objects.create_user(uname, email, pass1)
#                 user.save()
#                 return redirect('login')

#     return render(request, 'crop_doc/register.html')


def register_view(request):
    if request.method == 'POST':
        uname = request.POST.get('username')
        email = request.POST.get('email')
        pass1 = request.POST.get('password1')
        pass2 = request.POST.get('password2')
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')

        if pass1 != pass2:
            return HttpResponse("Passwords do not match!")
        elif User.objects.filter(username=uname).exists():
            return HttpResponse("Username already exists!")
        elif User.objects.filter(email=email).exists():
            return HttpResponse("Email already registered!")
        else:
            user = User.objects.create_user(username=uname, email=email, password=pass1)
            #user.first_name = first_name
            #user.last_name = last_name
            user.save()
            return redirect('login')

    return render(request, 'crop_doc/register.html')


@login_required(login_url='login')
def scan_view(request):
    return render(request, 'crop_doc/scan.html')


def index_view(request):
  return render(request, 'crop_doc/index.html')

#def index_view(request):
 #   return render(request, 'crop_doc/index.html')

@login_required(login_url='login')
def environment_view(request):
    return render(request, 'crop_doc/environment.html')

@login_required(login_url='login')
def market_view(request):
    return render(request, 'crop_doc/market.html')


@login_required(login_url='login')
def knowledge_view(request):
    return render(request, 'crop_doc/knowledge.html')

def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            # if user.is_superuser or user.is_staff:
            #     return redirect('/admin/')
            # else:
            return redirect('/index/')
        else:
            #messages.error(request, 'Invalid email or password.')
            return HttpResponse ("name or Password is incorrect!!!")

    return render(request, 'login.html')


@login_required(login_url='login')
def scan_view(request):
    return render(request, 'crop_doc/scan.html')


@login_required(login_url='login')
def result_view(request):
    return render(request, 'crop_doc/result.html')


@login_required(login_url='login')
def userdashboard_view(request):
    return render(request, 'crop_doc/userdashboard.html')


def LogoutPage(request):
    logout(request)
    return redirect('login')

def dashboard(request):
    # Get current date
    current_date = timezone.now().strftime("%B %d, %Y")
    
    # Mock data for demonstration (replace with actual database queries)
    context = {
        'current_date': current_date,
        'active_crops_count': 5,
        'upcoming_tasks_count': 3,
        'weather_condition': 'Sunny, 28°C',
        'crop_health_status': 'Good',
        'recent_activities': [
            {
                'icon': 'fa-seedling',
                'title': 'New Crop Added',
                'description': 'Wheat planted in Field A',
                'date': '2 hours ago'
            },
            {
                'icon': 'fa-tint',
                'title': 'Irrigation Completed',
                'description': 'Field B watered',
                'date': '5 hours ago'
            },
            {
                'icon': 'fa-calendar-check',
                'title': 'Task Scheduled',
                'description': 'Fertilization scheduled for tomorrow',
                'date': '1 day ago'
            }
        ],
        'weather_forecast': [
            {
                'date': 'Today',
                'icon': 'fa-sun',
                'temperature': 28,
                'condition': 'Sunny'
            },
            {
                'date': 'Tomorrow',
                'icon': 'fa-cloud-sun',
                'temperature': 26,
                'condition': 'Partly Cloudy'
            },
            {
                'date': 'Wed',
                'icon': 'fa-cloud-rain',
                'temperature': 24,
                'condition': 'Light Rain'
            }
        ],
        'crop_health': [
            {
                'name': 'Wheat',
                'status': 'Growing Well',
                'health_class': 'good'
            },
            {
                'name': 'Corn',
                'status': 'Needs Attention',
                'health_class': 'warning'
            },
            {
                'name': 'Soybeans',
                'status': 'Excellent',
                'health_class': 'good'
            }
        ]
    }
    
    return render(request, 'crop_doc/dashboard.html', context)
